setTimeout(function(){
    app.flash('<i class="fa fa-arrow-up pull-right" style="margin-right: 10px;"></i> There is a search tool available here', 'info');
}, 10000);
