app.flash('I am javascript !', 'info');
